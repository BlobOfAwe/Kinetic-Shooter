// ## - ZS
using UnityEngine;

/// <summary>
/// THIS CODE IS NOW OBSOLETE:
/// It has been rolled into Item.cs
/// - JV
/// </summary>
[System.Serializable]

//manages the data for the pickups
public class Pickup
    {
        public string title;
        public string description;
        public Sprite icon;
    }
